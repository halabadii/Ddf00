package com.example.lifeavatar

import android.app.Application
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Habit(val id: String, val title: String, val xp: Int)

val TRAITS = listOf(
    "social" to ("انطوائي" to "اجتماعي"),
    "energy" to ("هادي" to "نشيط"),
    "order" to ("عفوي" to "منظّم"),
    "humor" to ("جدّي" to "مرح"),
    "openness" to ("تقليدي" to "مبدع")
)
val LEVEL_TITLES = listOf("مبتدئ", "متحمّس", "ملتزم", "منضبط", "واثق", "متوازن", "قيادي", "حكيم", "أسطورة", "النسخة المثالية")

class AppVm(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("lifeavatar", 0)
    private val today = LocalDate.now().toString()

    var onboarded by mutableStateOf(sp.getBoolean("onboarded", false))
    var name by mutableStateOf(sp.getString("name", "") ?: "")
    var goal by mutableStateOf(sp.getString("goal", "") ?: "")
    val traits = mutableStateMapOf<String, Int>().apply {
        TRAITS.forEach { put(it.first, sp.getInt("t_${it.first}", 3)) }
    }
    var xp by mutableIntStateOf(sp.getInt("xp", 0))
    val habits = mutableStateListOf<Habit>()
    val done = mutableStateListOf<String>()
    var yesterdayRatio by mutableFloatStateOf(0f)
    var form by mutableStateOf(Form())
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val chat = mutableStateListOf<Pair<String, String>>()

    val level get() = minOf(10, 1 + Math.sqrt(xp / 60.0).toInt())
    val levelProgress: Float get() {
        val cur = 60.0 * (level - 1) * (level - 1); val next = 60.0 * level * level
        return if (level >= 10) 1f else ((xp - cur) / (next - cur)).toFloat().coerceIn(0f, 1f)
    }
    val mood: Int get() {
        val t = if (habits.isEmpty()) 0f else done.size.toFloat() / habits.size
        val s = 0.6f * t + 0.4f * yesterdayRatio
        return when { s < 0.25f -> 0; s < 0.5f -> 1; s < 0.8f -> 2; else -> 3 }
    }

    init {
        // عادات افتراضية (عدّلها/زيدها من التطبيق)
        val saved = sp.getString("habits", null)
        if (saved != null) {
            val a = JSONArray(saved)
            for (i in 0 until a.length()) a.getJSONObject(i).let { habits.add(Habit(it.getString("id"), it.getString("t"), it.getInt("xp"))) }
        } else listOf(
            Habit("sleep", "نمت وصحيت بموعد ثابت", 25),
            Habit("workout", "تمرين ٢٠ دقيقة", 30),
            Habit("food", "أكلت وجبة صحية", 20),
            Habit("focus", "ساعة تركيز بدون جوال", 30),
            Habit("phone", "قلّلت وقت الشاشة", 20),
            Habit("mood", "سجّلت مزاجي وفكّرت بيومي", 15)
        ).forEach { habits.add(it) }

        // تصفير يومي
        val lastDay = sp.getString("day", today)
        val lastDone = sp.getStringSet("done", emptySet()) ?: emptySet()
        if (lastDay == today) done.addAll(lastDone)
        else yesterdayRatio = if (habits.isEmpty()) 0f else lastDone.size.toFloat() / habits.size
        sp.getString("form_${level}", null)?.let { form = parseForm(it) }
        sp.getString("chat", null)?.let { s ->
            val a = JSONArray(s); for (i in 0 until a.length()) a.getJSONArray(i).let { chat.add(it.getString(0) to it.getString(1)) }
        }
        save()
    }

    private fun save() = sp.edit()
        .putBoolean("onboarded", onboarded).putString("name", name).putString("goal", goal)
        .putInt("xp", xp).putString("day", today).putStringSet("done", done.toSet())
        .putString("habits", JSONArray().also { a -> habits.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("xp", it.xp)) } }.toString())
        .putString("chat", JSONArray().also { a -> chat.takeLast(40).forEach { a.put(JSONArray().put(it.first).put(it.second)) } }.toString())
        .also { e -> traits.forEach { (k, v) -> e.putInt("t_$k", v) } }
        .apply()

    fun finishOnboarding() { onboarded = true; save(); requestForm() }

    fun toggle(h: Habit) {
        val before = level
        if (done.contains(h.id)) { done.remove(h.id); xp = maxOf(0, xp - h.xp) }
        else { done.add(h.id); xp += h.xp }
        save()
        if (level != before) {
            val cached = sp.getString("form_$level", null)
            if (cached != null) form = parseForm(cached) else requestForm()
        }
    }

    fun addHabit(title: String) {
        if (title.isBlank()) return
        habits.add(Habit("c${System.currentTimeMillis()}", title.trim(), 20)); save()
    }

    private fun personaSummary() = TRAITS.joinToString("، ") { (k, p) ->
        "${p.first}↔${p.second}: ${traits[k]}/5"
    } + ". الهدف: $goal"

    /** Gemini يبني شكل الشخصية للفل الحالي حسب شخصيتك الحقيقية */
    fun requestForm() = viewModelScope.launch {
        busy = true; error = null
        val lv = level
        try {
            val system = """أنت مصمم شخصيات. الشخصية هي "النسخة المتطورة" من المستخدم واسمه $name، وتشبه شخصيته الحقيقية (لا تغيّر طبعه الأساسي، فقط تنضج).
كلما زاد اللفل (1-10) تصير أنضج وأثبت وأكثر ثقة وهدوءاً مع بقاء نفس الروح.
رجّع JSON فقط بهذا الشكل:
{"title":"لقب قصير للفل","outfit":"#RRGGBB","hair":"#RRGGBB","hairStyle":0-3,"accessory":"none|glasses|cape|crown|aura","speechStyle":"وصف أسلوب الكلام بجملة","greeting":"جملة ترحيب قصيرة بلهجة شامية"}
الإكسسوار الأفخم للفلات العالية. الألوان تعكس الطبع (هادي=ألوان باردة، نشيط=دافئة)."""
            val raw = Gemini.ask(system, listOf("user" to "الشخصية: ${personaSummary()}\nاللفل: $lv (${LEVEL_TITLES[lv - 1]})"), json = true)
            sp.edit().putString("form_$lv", raw).apply()
            form = parseForm(raw)
        } catch (e: Exception) { error = e.message }
        busy = false
    }

    private fun parseForm(raw: String): Form = try {
        val j = JSONObject(raw)
        Form(
            title = j.optString("title", LEVEL_TITLES[level - 1]),
            outfit = AColor.parseColor(j.optString("outfit", "#4F7CAC")).toLong() and 0xFFFFFFFF,
            hair = AColor.parseColor(j.optString("hair", "#3B2A1A")).toLong() and 0xFFFFFFFF,
            hairStyle = j.optInt("hairStyle", 0).coerceIn(0, 3),
            accessory = j.optString("accessory", "none"),
            speechStyle = j.optString("speechStyle", ""),
            greeting = j.optString("greeting", "")
        )
    } catch (e: Exception) { Form(title = LEVEL_TITLES[level - 1]) }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        chat.add("user" to text); save(); busy = true; error = null
        viewModelScope.launch {
            try {
                val moodTxt = listOf("تعبان وطاقته واطية", "عادي", "منيح", "مبسوط ومتحمس")[mood]
                val system = """أنت ${form.title}، النسخة المتطورة (لفل $level من 10) من $name. شخصيته: ${personaSummary()}.
أسلوب كلامك: ${form.speechStyle}. مزاجك اليوم: $moodTxt (يعكس التزام $name الفعلي اليوم). أنجز ${done.size} من ${habits.size} عادات.
احكِ بلهجة شامية قصيرة. كن صادق ومباشر بدون مديح فارغ، وإذا في تقصير قله بلطف. اقترح خطوة عملية واحدة. لا تعطِ نصائح طبية أو تشخيص."""
                val reply = Gemini.ask(system, chat.takeLast(12).map { (if (it.first == "user") "user" else "model") to it.second })
                chat.add("model" to reply); save()
            } catch (e: Exception) { error = e.message }
            busy = false
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { Root() } }
            }
        }
    }
}

@Composable
fun Root(vm: AppVm = viewModel()) {
    if (!vm.onboarded) { Onboarding(vm); return }
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("شخصيتي", "عاداتي", "احكي معه").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("🧍", "✅", "💬")[i]) }, label = { Text(t) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> Home(vm); 1 -> Habits(vm); else -> Chat(vm) }
        }
    }
}

@Composable
fun Onboarding(vm: AppVm) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("خلينا نبني نسختك المتطورة", style = MaterialTheme.typography.headlineSmall) }
        item { OutlinedTextField(vm.name, { vm.name = it }, label = { Text("اسمك") }, modifier = Modifier.fillMaxWidth()) }
        items(TRAITS) { (k, p) ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(p.first); Text(p.second) }
                Slider((vm.traits[k] ?: 3).toFloat(), { vm.traits[k] = it.toInt() }, valueRange = 1f..5f, steps = 3)
            }
        }
        item { OutlinedTextField(vm.goal, { vm.goal = it }, label = { Text("شو أهم شي بدك تطوره بنفسك؟") }, modifier = Modifier.fillMaxWidth()) }
        item { Button({ vm.finishOnboarding() }, enabled = vm.name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("ابدأ") } }
    }
}

@Composable
fun Home(vm: AppVm) {
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("لفل ${vm.level} • ${vm.form.title}", style = MaterialTheme.typography.titleLarge)
        LinearProgressIndicator(progress = { vm.levelProgress }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        Text("${vm.xp} XP", style = MaterialTheme.typography.labelMedium)
        Avatar(vm.form, vm.level, vm.mood)
        Text(vm.form.greeting, style = MaterialTheme.typography.bodyLarge)
        Text("المزاج: " + listOf("😞 تعبان", "😐 عادي", "🙂 منيح", "😄 مبسوط")[vm.mood])
        if (vm.busy) CircularProgressIndicator(Modifier.padding(8.dp))
        vm.error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            TextButton({ vm.requestForm() }) { Text("جرّب مرة ثانية") }
        }
    }
}

@Composable
fun Habits(vm: AppVm) {
    var newHabit by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { Text("عادات اليوم (${vm.done.size}/${vm.habits.size})", style = MaterialTheme.typography.titleMedium) }
        items(vm.habits) { h ->
            Card(Modifier.fillMaxWidth(), onClick = { vm.toggle(h) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(vm.done.contains(h.id), { vm.toggle(h) })
                    Text(h.title, Modifier.weight(1f)); Text("+${h.xp}")
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(newHabit, { newHabit = it }, label = { Text("عادة جديدة") }, modifier = Modifier.weight(1f))
                TextButton({ vm.addHabit(newHabit); newHabit = "" }) { Text("زيد") }
            }
        }
    }
}

@Composable
fun Chat(vm: AppVm) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.chat.reversed()) { (role, text) ->
                val me = role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.Start else Arrangement.End) {
                    Surface(shape = MaterialTheme.shapes.medium, color = if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer) {
                        Text(text, Modifier.padding(10.dp).widthIn(max = 280.dp))
                    }
                }
            }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("احكي معه...") })
            Button({ vm.send(input); input = "" }) { Text("ارسل") }
        }
    }
}
