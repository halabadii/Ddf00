package com.example.lifeavatar

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** history: قائمة (role, text) حيث role = "user" أو "model". آخر عنصر لازم يكون "user". */
object Gemini {
    suspend fun ask(
        system: String,
        history: List<Pair<String, String>>,
        json: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        require(BuildConfig.GEMINI_API_KEY.isNotBlank()) { "ضيف GEMINI_API_KEY في local.properties" }
        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(JSONObject().put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${BuildConfig.GEMINI_MODEL}:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream.bufferedReader().readText()
            if (c.responseCode !in 200..299) error("Gemini ${c.responseCode}: ${text.take(200)}")
            JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } finally { c.disconnect() }
    }
}
