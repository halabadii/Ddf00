package com.example.lifeavatar

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/** شكل الشخصية لكل لفل (يولّده Gemini حسب شخصيتك) */
data class Form(
    val title: String = "مبتدئ",
    val outfit: Long = 0xFF4F7CAC,
    val hair: Long = 0xFF3B2A1A,
    val hairStyle: Int = 0,          // 0 قصير، 1 طويل، 2 كعكة، 3 خفيف
    val accessory: String = "none",  // none | glasses | cape | crown | aura
    val speechStyle: String = "بسيط وهادي",
    val greeting: String = "أهلين، خلينا نبدأ."
)

/** mood: 0 تعبان، 1 عادي، 2 منيح، 3 مبسوط */
@Composable
fun Avatar(form: Form, level: Int, mood: Int, modifier: Modifier = Modifier) {
    val skin = Color(0xFFF1C27D)
    val outfit = Color(form.outfit)
    val hair = Color(form.hair)
    Canvas(modifier.size(280.dp)) {
        val w = size.width
        val cx = w / 2
        val headY = w * 0.40f
        val r = w * 0.17f

        // هالة تكبر مع اللفل
        if (level >= 3 || form.accessory == "aura") {
            drawCircle(
                Brush.radialGradient(
                    listOf(outfit.copy(alpha = 0.10f + 0.03f * level), Color.Transparent),
                    center = Offset(cx, w * 0.5f), radius = w * 0.5f
                ), radius = w * 0.5f, center = Offset(cx, w * 0.5f)
            )
        }
        val tilt = if (mood == 0) 5f else 0f
        rotate(tilt, pivot = Offset(cx, w * 0.98f)) {
            val shoulder = w * (0.24f + 0.012f * level)
            // عباءة
            if (form.accessory == "cape") {
                val cape = Path().apply {
                    moveTo(cx - shoulder, w * 0.66f); lineTo(cx - shoulder * 1.25f, w)
                    lineTo(cx + shoulder * 1.25f, w); lineTo(cx + shoulder, w * 0.66f); close()
                }
                drawPath(cape, outfit.copy(alpha = 0.55f))
            }
            // جسم
            val body = Path().apply {
                moveTo(cx - shoulder, w); lineTo(cx - shoulder * 0.8f, w * 0.68f)
                quadTo(cx, w * 0.60f, cx + shoulder * 0.8f, w * 0.68f)
                lineTo(cx + shoulder, w); close()
            }
            drawPath(body, outfit)
            // رقبة
            drawRect(skin, Offset(cx - r * 0.3f, headY + r * 0.7f), Size(r * 0.6f, r * 0.7f))
            // شعر خلفي للطويل
            if (form.hairStyle == 1)
                drawRect(hair, Offset(cx - r * 1.05f, headY - r * 0.2f), Size(r * 2.1f, r * 1.8f))
            // رأس
            drawCircle(skin, r, Offset(cx, headY))
            // شعر
            when (form.hairStyle) {
                0, 1 -> drawArc(hair, 180f, 180f, true, Offset(cx - r * 1.05f, headY - r * 1.05f), Size(r * 2.1f, r * 1.5f))
                2 -> {
                    drawArc(hair, 180f, 180f, true, Offset(cx - r * 1.05f, headY - r * 1.05f), Size(r * 2.1f, r * 1.5f))
                    drawCircle(hair, r * 0.45f, Offset(cx, headY - r * 1.25f))
                }
                else -> drawArc(hair, 200f, 140f, true, Offset(cx - r, headY - r), Size(r * 2f, r * 1.1f))
            }
            // عيون
            val eyeY = headY - r * 0.05f
            val eyeR = r * (if (mood == 0) 0.09f else 0.12f)
            drawCircle(Color(0xFF222222), eyeR, Offset(cx - r * 0.4f, eyeY))
            drawCircle(Color(0xFF222222), eyeR, Offset(cx + r * 0.4f, eyeY))
            // حواجب
            val inner = when (mood) { 0 -> -r * 0.18f; 3 -> r * 0.05f; else -> 0f }
            val bs = Stroke(width = r * 0.07f)
            drawLine(Color(0xFF222222), Offset(cx - r * 0.6f, eyeY - r * 0.3f),
                Offset(cx - r * 0.2f, eyeY - r * 0.3f + inner), bs.width)
            drawLine(Color(0xFF222222), Offset(cx + r * 0.6f, eyeY - r * 0.3f),
                Offset(cx + r * 0.2f, eyeY - r * 0.3f + inner), bs.width)
            // فم
            val my = headY + r * 0.5f
            val ctrl = my + r * listOf(-0.25f, 0f, 0.22f, 0.42f)[mood]
            val mouth = Path().apply {
                moveTo(cx - r * 0.35f, my); quadraticBezierTo(cx, ctrl, cx + r * 0.35f, my)
            }
            drawPath(mouth, Color(0xFF7A2E2E), style = Stroke(width = r * 0.08f))
            // إكسسوارات
            if (form.accessory == "glasses") {
                val gs = Stroke(width = r * 0.06f)
                drawCircle(Color(0xFF333333), r * 0.28f, Offset(cx - r * 0.4f, eyeY), style = gs)
                drawCircle(Color(0xFF333333), r * 0.28f, Offset(cx + r * 0.4f, eyeY), style = gs)
                drawLine(Color(0xFF333333), Offset(cx - r * 0.12f, eyeY), Offset(cx + r * 0.12f, eyeY), gs.width)
            }
            if (form.accessory == "crown") {
                val cy = headY - r * 1.0f
                val crown = Path().apply {
                    moveTo(cx - r * 0.7f, cy); lineTo(cx - r * 0.7f, cy - r * 0.5f)
                    lineTo(cx - r * 0.35f, cy - r * 0.2f); lineTo(cx, cy - r * 0.6f)
                    lineTo(cx + r * 0.35f, cy - r * 0.2f); lineTo(cx + r * 0.7f, cy - r * 0.5f)
                    lineTo(cx + r * 0.7f, cy); close()
                }
                drawPath(crown, Color(0xFFFFC107))
            }
        }
    }
}
